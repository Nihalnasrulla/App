import csv
import io
import os
from datetime import datetime, date

from flask import (
    Flask, render_template, redirect, url_for, request, flash,
    jsonify, session, Response
)
from flask_login import (
    LoginManager, login_user, logout_user, login_required,
    current_user
)

from models import db, Admin, Mall, Employee, Attendance
from geofence import is_within_radius

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-secret-key-in-production")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(BASE_DIR, "attendance.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db.init_app(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"


def ensure_database_ready():
    """Create tables and a default admin on first run. Safe to call every
    startup — it does nothing if already initialized. This lets the app
    deploy on free hosting platforms with a single click, no shell access
    or manual 'flask init-db' step required."""
    db.create_all()
    if not Admin.query.filter_by(username="admin").first():
        default_admin = Admin(username="admin")
        default_admin.set_password(os.environ.get("DEFAULT_ADMIN_PASSWORD", "changeme123"))
        db.session.add(default_admin)
        db.session.commit()


with app.app_context():
    ensure_database_ready()


@login_manager.user_loader
def load_user(user_id):
    # IDs are prefixed so we know which table to check ("admin-3" or "employee-7")
    kind, _, raw_id = user_id.partition("-")
    if kind == "admin":
        return Admin.query.get(int(raw_id))
    elif kind == "employee":
        return Employee.query.get(int(raw_id))
    return None


def admin_required(func):
    """Decorator: only allow logged-in Admins (not Employees) to access a route."""
    from functools import wraps

    @wraps(func)
    @login_required
    def wrapper(*args, **kwargs):
        if not isinstance(current_user._get_current_object(), Admin):
            flash("Admin access required.", "error")
            return redirect(url_for("login"))
        return func(*args, **kwargs)
    return wrapper


# ---------------------------------------------------------------------------
# Home / landing
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    if current_user.is_authenticated:
        if isinstance(current_user._get_current_object(), Admin):
            return redirect(url_for("admin_dashboard"))
        return redirect(url_for("checkin_page"))
    return redirect(url_for("login"))


# ---------------------------------------------------------------------------
# Unified login: tries Admin first, then Employee (by employee_code + PIN)
# ---------------------------------------------------------------------------

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        identifier = request.form.get("identifier", "").strip()
        secret = request.form.get("secret", "").strip()

        admin = Admin.query.filter_by(username=identifier).first()
        if admin and admin.check_password(secret):
            login_user(admin)
            return redirect(url_for("admin_dashboard"))

        employee = Employee.query.filter_by(employee_code=identifier, active=True).first()
        if employee and employee.check_pin(secret):
            login_user(employee)
            return redirect(url_for("checkin_page"))

        flash("Invalid login details. Please check your ID/PIN and try again.", "error")
    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))


# ---------------------------------------------------------------------------
# Employee-facing: check in / check out
# ---------------------------------------------------------------------------

@app.route("/checkin")
@login_required
def checkin_page():
    if isinstance(current_user._get_current_object(), Admin):
        return redirect(url_for("admin_dashboard"))

    employee = current_user._get_current_object()
    today = date.today()
    open_record = Attendance.query.filter(
        Attendance.employee_id == employee.id,
        db.func.date(Attendance.created_at) == today,
        Attendance.check_out.is_(None)
    ).order_by(Attendance.id.desc()).first()

    return render_template("checkin.html", employee=employee, open_record=open_record)


@app.route("/api/checkin", methods=["POST"])
@login_required
def api_checkin():
    employee = current_user._get_current_object()
    if isinstance(employee, Admin):
        return jsonify({"success": False, "message": "Admins cannot check in."}), 403

    data = request.get_json(force=True)
    lat = data.get("latitude")
    lng = data.get("longitude")

    if lat is None or lng is None:
        return jsonify({"success": False, "message": "Location not available. Please enable GPS/location and try again."}), 400

    mall = employee.mall
    within, distance = is_within_radius(lat, lng, mall.latitude, mall.longitude, mall.radius_m)

    if not within:
        return jsonify({
            "success": False,
            "message": (
                f"You are {int(distance)}m away from {mall.name}. "
                f"You must be within {mall.radius_m}m to check in."
            )
        }), 400

    record = Attendance(
        employee_id=employee.id,
        check_in=datetime.utcnow(),
        check_in_lat=lat,
        check_in_lng=lng,
        check_in_distance_m=distance,
    )
    db.session.add(record)
    db.session.commit()

    return jsonify({"success": True, "message": f"Checked in at {mall.name}. Have a great shift!"})


@app.route("/api/checkout", methods=["POST"])
@login_required
def api_checkout():
    employee = current_user._get_current_object()
    if isinstance(employee, Admin):
        return jsonify({"success": False, "message": "Admins cannot check out."}), 403

    data = request.get_json(force=True)
    lat = data.get("latitude")
    lng = data.get("longitude")

    if lat is None or lng is None:
        return jsonify({"success": False, "message": "Location not available. Please enable GPS/location and try again."}), 400

    mall = employee.mall
    within, distance = is_within_radius(lat, lng, mall.latitude, mall.longitude, mall.radius_m)

    if not within:
        return jsonify({
            "success": False,
            "message": (
                f"You are {int(distance)}m away from {mall.name}. "
                f"You must be within {mall.radius_m}m to check out."
            )
        }), 400

    today = date.today()
    record = Attendance.query.filter(
        Attendance.employee_id == employee.id,
        db.func.date(Attendance.created_at) == today,
        Attendance.check_out.is_(None)
    ).order_by(Attendance.id.desc()).first()

    if not record:
        return jsonify({"success": False, "message": "No open check-in found for today."}), 400

    record.check_out = datetime.utcnow()
    record.check_out_lat = lat
    record.check_out_lng = lng
    record.check_out_distance_m = distance
    db.session.commit()

    return jsonify({"success": True, "message": f"Checked out from {mall.name}. See you next shift!"})


# ---------------------------------------------------------------------------
# Admin: dashboard
# ---------------------------------------------------------------------------

@app.route("/admin")
@admin_required
def admin_dashboard():
    mall_count = Mall.query.count()
    employee_count = Employee.query.filter_by(active=True).count()
    today = date.today()
    today_checkins = Attendance.query.filter(
        db.func.date(Attendance.created_at) == today
    ).count()
    return render_template(
        "admin_dashboard.html",
        mall_count=mall_count,
        employee_count=employee_count,
        today_checkins=today_checkins,
    )


# ---------------------------------------------------------------------------
# Admin: malls (work locations)
# ---------------------------------------------------------------------------

@app.route("/admin/malls", methods=["GET", "POST"])
@admin_required
def admin_malls():
    if request.method == "POST":
        try:
            mall = Mall(
                name=request.form["name"].strip(),
                latitude=float(request.form["latitude"]),
                longitude=float(request.form["longitude"]),
                radius_m=int(request.form["radius_m"]),
            )
            db.session.add(mall)
            db.session.commit()
            flash(f"Mall '{mall.name}' added.", "success")
        except (KeyError, ValueError):
            flash("Please fill all fields with valid numbers.", "error")
        return redirect(url_for("admin_malls"))

    malls = Mall.query.order_by(Mall.name).all()
    return render_template("admin_malls.html", malls=malls)


@app.route("/admin/malls/<int:mall_id>/edit", methods=["GET", "POST"])
@admin_required
def admin_mall_edit(mall_id):
    mall = Mall.query.get_or_404(mall_id)
    if request.method == "POST":
        try:
            mall.name = request.form["name"].strip()
            mall.latitude = float(request.form["latitude"])
            mall.longitude = float(request.form["longitude"])
            mall.radius_m = int(request.form["radius_m"])
            db.session.commit()
            flash(f"Mall '{mall.name}' updated.", "success")
            return redirect(url_for("admin_malls"))
        except (KeyError, ValueError):
            flash("Please fill all fields with valid numbers.", "error")
    return render_template("admin_mall_form.html", mall=mall)


@app.route("/admin/malls/<int:mall_id>/delete", methods=["POST"])
@admin_required
def admin_mall_delete(mall_id):
    mall = Mall.query.get_or_404(mall_id)
    if mall.employees:
        flash("Cannot delete a mall that has employees assigned to it. Reassign them first.", "error")
    else:
        db.session.delete(mall)
        db.session.commit()
        flash("Mall deleted.", "success")
    return redirect(url_for("admin_malls"))


# ---------------------------------------------------------------------------
# Admin: employees
# ---------------------------------------------------------------------------

@app.route("/admin/employees", methods=["GET", "POST"])
@admin_required
def admin_employees():
    malls = Mall.query.order_by(Mall.name).all()

    if request.method == "POST":
        try:
            employee = Employee(
                name=request.form["name"].strip(),
                employee_code=request.form["employee_code"].strip(),
                mall_id=int(request.form["mall_id"]),
            )
            employee.set_pin(request.form["pin"].strip())
            db.session.add(employee)
            db.session.commit()
            flash(f"Employee '{employee.name}' added.", "success")
        except (KeyError, ValueError):
            flash("Please fill all fields correctly.", "error")
        except Exception:
            db.session.rollback()
            flash("That employee code is already in use.", "error")
        return redirect(url_for("admin_employees"))

    employees = Employee.query.order_by(Employee.name).all()
    return render_template("admin_employees.html", employees=employees, malls=malls)


@app.route("/admin/employees/<int:employee_id>/edit", methods=["GET", "POST"])
@admin_required
def admin_employee_edit(employee_id):
    employee = Employee.query.get_or_404(employee_id)
    malls = Mall.query.order_by(Mall.name).all()

    if request.method == "POST":
        try:
            employee.name = request.form["name"].strip()
            employee.employee_code = request.form["employee_code"].strip()
            employee.mall_id = int(request.form["mall_id"])
            employee.active = "active" in request.form
            new_pin = request.form.get("pin", "").strip()
            if new_pin:
                employee.set_pin(new_pin)
            db.session.commit()
            flash(f"Employee '{employee.name}' updated.", "success")
            return redirect(url_for("admin_employees"))
        except (KeyError, ValueError):
            flash("Please fill all fields correctly.", "error")

    return render_template("admin_employee_form.html", employee=employee, malls=malls)


@app.route("/admin/employees/<int:employee_id>/delete", methods=["POST"])
@admin_required
def admin_employee_delete(employee_id):
    employee = Employee.query.get_or_404(employee_id)
    db.session.delete(employee)
    db.session.commit()
    flash("Employee deleted.", "success")
    return redirect(url_for("admin_employees"))


# ---------------------------------------------------------------------------
# Admin: attendance records + Odoo export
# ---------------------------------------------------------------------------

@app.route("/admin/attendance")
@admin_required
def admin_attendance():
    month = request.args.get("month")  # format YYYY-MM
    query = Attendance.query.join(Employee)

    if month:
        year, mon = month.split("-")
        query = query.filter(
            db.extract("year", Attendance.created_at) == int(year),
            db.extract("month", Attendance.created_at) == int(mon),
        )

    records = query.order_by(Attendance.created_at.desc()).all()
    return render_template("admin_attendance.html", records=records, selected_month=month)


@app.route("/admin/attendance/export")
@admin_required
def admin_attendance_export():
    """Export attendance as a CSV formatted for Odoo's Attendance import
    (columns: Employee's Badge ID / Employee, Check In, Check Out)."""
    month = request.args.get("month")
    query = Attendance.query.join(Employee)

    if month:
        year, mon = month.split("-")
        query = query.filter(
            db.extract("year", Attendance.created_at) == int(year),
            db.extract("month", Attendance.created_at) == int(mon),
        )

    records = query.order_by(Attendance.check_in).all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Employee ID", "Employee Name", "Check In", "Check Out"])

    for r in records:
        writer.writerow([
            r.employee.employee_code,
            r.employee.name,
            r.check_in.strftime("%Y-%m-%d %H:%M:%S") if r.check_in else "",
            r.check_out.strftime("%Y-%m-%d %H:%M:%S") if r.check_out else "",
        ])

    filename = f"attendance_export_{month or 'all'}.csv"
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


# ---------------------------------------------------------------------------
# Admin: account settings (change password)
# ---------------------------------------------------------------------------

@app.route("/admin/settings", methods=["GET", "POST"])
@admin_required
def admin_settings():
    admin = current_user._get_current_object()
    if request.method == "POST":
        current_pw = request.form.get("current_password", "")
        new_pw = request.form.get("new_password", "")
        confirm_pw = request.form.get("confirm_password", "")

        if not admin.check_password(current_pw):
            flash("Current password is incorrect.", "error")
        elif len(new_pw) < 8:
            flash("New password must be at least 8 characters.", "error")
        elif new_pw != confirm_pw:
            flash("New passwords do not match.", "error")
        else:
            admin.set_password(new_pw)
            db.session.commit()
            flash("Password updated successfully.", "success")
            return redirect(url_for("admin_dashboard"))

    return render_template("admin_settings.html")


# ---------------------------------------------------------------------------
# CLI helper: initialize the database with an admin user
# ---------------------------------------------------------------------------

@app.cli.command("init-db")
def init_db():
    """Create all tables and a default admin user (run once during setup)."""
    db.create_all()
    if not Admin.query.filter_by(username="admin").first():
        admin = Admin(username="admin")
        admin.set_password("changeme123")
        db.session.add(admin)
        db.session.commit()
        print("Database created. Default admin login -> username: admin | password: changeme123")
        print("IMPORTANT: log in and change this password immediately (see README).")
    else:
        print("Database already initialized.")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
