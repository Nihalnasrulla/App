"""Geofence distance calculation using the Haversine formula.

This computes the real-world distance (in meters) between two GPS
coordinates (the employee's reported location and the mall's registered
location), so we can enforce that check-in/out only happens on-site.
"""
import math


def distance_meters(lat1, lon1, lat2, lon2):
    """Return the great-circle distance in meters between two GPS points."""
    R = 6371000  # Earth radius in meters
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    d_phi = math.radians(lat2 - lat1)
    d_lambda = math.radians(lon2 - lon1)

    a = (
        math.sin(d_phi / 2) ** 2
        + math.cos(phi1) * math.cos(phi2) * math.sin(d_lambda / 2) ** 2
    )
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c


def is_within_radius(lat1, lon1, lat2, lon2, radius_m):
    """Check whether point 1 is within radius_m meters of point 2."""
    d = distance_meters(lat1, lon1, lat2, lon2)
    return d <= radius_m, d
