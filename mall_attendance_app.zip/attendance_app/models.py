from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


class Admin(UserMixin, db.Model):
    """Admin/HR user who manages malls, employees, and exports data."""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)

    def get_id(self):
        return f"admin-{self.id}"

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Mall(db.Model):
    """A mall / work location with GPS coordinates and allowed check-in radius."""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    radius_m = db.Column(db.Integer, nullable=False, default=100)  # allowed radius in meters
    employees = db.relationship("Employee", backref="mall", lazy=True)


class Employee(UserMixin, db.Model):
    """A merchandiser/outsourced employee who checks in/out via the app."""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    employee_code = db.Column(db.String(50), unique=True, nullable=False)  # should match Odoo employee code
    pin_hash = db.Column(db.String(255), nullable=False)
    mall_id = db.Column(db.Integer, db.ForeignKey("mall.id"), nullable=False)
    active = db.Column(db.Boolean, default=True)

    attendances = db.relationship("Attendance", backref="employee", lazy=True)

    def get_id(self):
        return f"employee-{self.id}"

    def set_pin(self, pin):
        self.pin_hash = generate_password_hash(pin)

    def check_pin(self, pin):
        return check_password_hash(self.pin_hash, pin)


class Attendance(db.Model):
    """A single day's check-in/check-out record for an employee."""
    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.Integer, db.ForeignKey("employee.id"), nullable=False)

    check_in = db.Column(db.DateTime, nullable=True)
    check_in_lat = db.Column(db.Float, nullable=True)
    check_in_lng = db.Column(db.Float, nullable=True)
    check_in_distance_m = db.Column(db.Float, nullable=True)

    check_out = db.Column(db.DateTime, nullable=True)
    check_out_lat = db.Column(db.Float, nullable=True)
    check_out_lng = db.Column(db.Float, nullable=True)
    check_out_distance_m = db.Column(db.Float, nullable=True)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
