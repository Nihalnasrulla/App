# Mall Attendance App

## 🚀 Quick demo (free hosting, no server needed) — start here

Want to showcase this to your team before buying a server? Use **Render.com**
(free tier). It gives you a real HTTPS link in a few minutes, no coding, no
credit card. Two limitations to know for the demo phase:
- Free apps "sleep" after 15 minutes of no traffic — the first click after
  that takes ~30-50 seconds to wake up. Fine for a scheduled demo.
- Free storage resets whenever you redeploy — fine for showcasing, but
  once your team approves it, move to your own server (Section 2 below)
  before using it with real employees/real payroll data.

### Steps:
1. Create a free account at **github.com** (if you don't have one).
2. Create a new repository (e.g. `mall-attendance-demo`) → click
   **"uploading an existing file"** → drag in every file from this folder
   (keeping the `templates` and `static` folders intact) → commit.
3. Create a free account at **render.com**, signing in with your GitHub
   account.
4. Click **New → Web Service** → select your `mall-attendance-demo` repo.
5. Fill in:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn app:app`
   - **Instance Type:** Free
6. Click **Create Web Service**. Render will give you a live link like
   `https://mall-attendance-demo.onrender.com` within a couple of minutes —
   this already has HTTPS, so GPS check-in will work immediately.
7. Log in with `admin` / `changeme123`, change the password (Settings), and
   add a mall + a test employee to walk your team through it live.

That's it — no server, no SSL setup, no command line. When you're ready to
go live for real, follow Section 2 below to move it to your own server.

---


A simple, self-hosted attendance system for outsourced merchandisers working
at malls. Employees check in/out from their phone browser; the system
verifies they are physically at their assigned mall (geofencing) before
accepting it. At month-end, you export a CSV and import it directly into
Odoo's Attendance module.

No coding knowledge is needed to run or manage this day-to-day — everything
after setup is done through the web admin panel in your browser.

---

## 1. What you need before starting

- A server or cloud VM you can access via SSH (Linux, e.g. Ubuntu) — you said
  you already have this.
- **A domain name pointed at that server, with HTTPS (SSL) enabled.**
  This is not optional: phone browsers **will not allow GPS location access**
  on a plain `http://` site (except on `localhost`). If your Odoo server
  already has a domain and SSL certificate, the easiest path is to run this
  app on the same server on a different port, behind the same reverse proxy.
- Python 3.9 or newer installed on the server (`python3 --version` to check).

If you're not sure whether you have HTTPS set up, tell me your setup (e.g.
"we use Nginx", "we use Apache", "not sure") and I'll give you the exact
steps for a free SSL certificate via Let's Encrypt.

---

## 2. One-time setup (copy-paste these commands)

Upload this whole `attendance_app` folder to your server (e.g. via `scp`,
FileZilla, or `git`), then run:

```bash
cd attendance_app

# Install Python dependencies
pip3 install -r requirements.txt --break-system-packages

# Create the database and a default admin account
export FLASK_APP=app.py
python3 -m flask init-db
```

You'll see:
```
Database created. Default admin login -> username: admin | password: changeme123
```

**Log in immediately and change this password** (Settings page, after login — see Section 4).

---

## 3. Running the app

### For quick testing (not for real use):
```bash
python3 app.py
```
This runs on port 5000. Visit `http://your-server-ip:5000` — but remember,
GPS check-in will only work over HTTPS, so this mode is just for you to look
around, not for merchandisers to use.

### For real, ongoing use (recommended):
Run it as a proper background service using `gunicorn` (a production server)
behind your existing web server (Nginx/Apache), the same way Odoo itself is
likely already set up. This keeps it running even after you log out or the
server restarts.

```bash
pip3 install gunicorn --break-system-packages
gunicorn --bind 127.0.0.1:8000 --daemon app:app
```

Then add a reverse proxy rule in Nginx (ask me for the exact config snippet
once I know your setup) so that something like
`https://attendance.yourcompany.com` forwards to `127.0.0.1:8000`, and set
that to auto-start on boot with a systemd service. I can write both of these
for you exactly if you tell me your domain and whether you use Nginx or
Apache.

---

## 4. Using the app (no coding — just clicking)

### First login
Go to your site's login page, sign in with `admin` / `changeme123`, then
go to **Settings** and change the password right away.

### Add your malls
Go to **Malls** → fill in:
- **Name** (e.g. "City Center Mall")
- **Latitude / Longitude** — open the mall in Google Maps, right-click the
  exact spot, click the coordinates that appear (e.g. `25.3181, 51.5310`) to
  copy them, and paste the two numbers into the two fields.
- **Radius (meters)** — how far from that exact point an employee is still
  allowed to check in. 100m is a reasonable default for a large mall; use
  50m for a tighter building.

### Add your employees
Go to **Employees** → fill in:
- Name
- **Employee ID** — ⚠️ make this match the employee's code/badge ID in
  Odoo exactly, so the export lines up automatically when you import it later.
- Assigned Mall
- A 4–6 digit PIN — this is what the employee will type in to log in (along
  with their Employee ID). No password complexity needed; it's meant to be
  simple for a phone.

Give each employee their **Employee ID + PIN** (e.g. via WhatsApp or printed
slip) and tell them to open the site link on their phone and (optionally)
"Add to Home Screen" so it behaves like an app icon.

### Daily use (for the merchandisers)
They open the link, log in once (it stays logged in), and just tap
**Check In** at the start of their shift and **Check Out** at the end. Their
phone will ask permission to share location the first time — they must tap
**Allow**. If they're not at their assigned mall, the system will reject the
check-in and tell them exactly how far off they are.

### Month-end (for you)
1. Go to **Attendance**, pick the month, and click **Export CSV for Odoo**.
2. In Odoo: go to the **Attendances** app → list view → **Favorites → Import
   records** → upload the CSV → map the columns (Employee ID/Employee Name →
   match to Odoo's Employee field, Check In, Check Out) → Import.
3. Payroll can now run immediately — no manual reconstruction needed.

---

## 5. Backups

All data lives in one file: `attendance.db` (created next to `app.py`).
Back this up regularly — e.g. a daily cron job copying it to another folder
or cloud storage:

```bash
cp attendance.db backups/attendance-$(date +%F).db
```

---

## 6. If something goes wrong

- **"Location permission denied" for employees** → they need to allow
  location access in their phone's browser settings for this site, and the
  site must be HTTPS.
- **Check-in rejected even though they're at the mall** → the mall's
  saved coordinates might be slightly off, or the radius is too tight.
  Edit the mall's coordinates/radius in the admin panel — no restart needed.
- **Forgot admin password** → run `python3 -m flask init-db` again after
  deleting `attendance.db` (⚠️ this wipes all data) — or ask me for a safer
  password-reset script instead.

If anything breaks or behaves unexpectedly, copy the exact error message and
bring it back to this conversation — I can debug it with you.
